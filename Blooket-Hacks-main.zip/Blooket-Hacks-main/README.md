TO THE PEOPLE  SAYING THESE ARE FAKE AND WILL GET YOU BANNED READ BELOW:

🌟PLEASE STAR THIS PROJECT🌟

Join the Discord for support: https://discord.gg/pushfr

if you get banned this is not my issue, as these are against Blooket's TOS

-lol-jude

# HOW TO USE:


Go to the url bar when you are in blooket
![Screenshot 2022-04-18 9 42 25 AM](https://user-images.githubusercontent.com/100436822/163824930-26969fa2-b8dd-4e09-bc0a-16a815298f30.png)
Type   "  **javascript:**  "
then paste your code in
it should look like this
![Screenshot 2022-04-18 9 45 50 AM](https://user-images.githubusercontent.com/100436822/163825308-ed7728b2-e31f-4f0a-826a-5f43e30cbc72.png)
(the text in the middle)
then, refresh your page and you should be good to go

THESE INSTRUCTIONS WERE PROVIDED BY @hankypoo7

## Warning
While using these hacks, there is a chance you can get banned. Use these at your own risk.
I am not responsible for if you get in any trouble while using these hacks.

# DO NOT STEAL MY WORK!

I am in the process of taking legal action against someone stealing my code and posting it as their own. They modified my code as well as deleted all credit towards me. Do not steal my work as I will take legal actions.

# Blooket Info

🌟PLEASE STAR THIS PROJECT🌟

Top 6 list of most popular/used codes...

Add Daily Tokens

ADD Daily Tokens This code will add 500 tokens which is the max daily limit and add the max xp which is 300 daily limit! 

Get Gold

Get Gold code will let you chose any amount of gold you want in the gold quest gamemode you can even get negative gold but not reccomended! 

Chest ESP

Chest ESP Works in multiple gamemodes works best in gold quest once you use this code you wil be able to see what you will get in the chest before even clicking on it so it is very usefull!

Get Crypto

The Get Crypto code is just like the Get gold code but only works in Crypto hack Gamemode. 

5.Get other users password 5. The get other users password code is slightly different to most of the other codes but when you are playing in the crypto hack gamemode and get the hack option in one of the chests use the code and it will tell you your victims password! 

Instant Win
Instant win code will automatically make you win in the racing mode.
There you go!

All codes still working!
